﻿using UnityEngine;


namespace GeekbrainsUnityCSharp
{
    public class BonusHolder : MonoBehaviour
    {

        #region Fields

        [SerializeField] private int _speedBonusTime = 15;
        [SerializeField] private int _bonusesToWin = 5;

        private Player _player;
        private GameEndController _gameEndController;
        private int _endBonusesCount = 0;

        #endregion

        #region UnityMethods

        private void Awake()
        {
            _player = GameObject.FindGameObjectWithTag("Player").GetComponent<Player>();
            _gameEndController = new GameEndController();

        }

        #endregion

        #region Methods

        public int AddEndBonus()
        {
            _endBonusesCount++;
            if (_endBonusesCount >= _bonusesToWin)
            {
                _gameEndController.EndGame();
            }
            return _endBonusesCount;
        }

        public void AddSpeedBonus()
        {
            DoubleSpeed();
            Invoke(nameof(DecreaseSpeed), _speedBonusTime);
        }

        public void AddSpeedPenalty()
        {
            DecreaseSpeed();
            Invoke(nameof(DecreaseSpeed), _speedBonusTime);
        }

        private void DoubleSpeed()
        {
            _player.Speed *= 2;
        }

        private void DecreaseSpeed()
        {
            _player.Speed /= 2;
        }

        #endregion

    }
}

﻿namespace GeekbrainsUnityCSharp
{

    public interface IAction
    {
        void Action();
    }
}

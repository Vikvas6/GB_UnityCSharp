﻿
namespace GeekbrainsUnityCSharp
{

    public sealed class GoodBonus : InteractiveObject
    {
        #region Methods

        protected override void Interact()
        {

        }

        public new string ToString()
        {
            return $"I am a {nameof(GoodBonus)} class method";
        }

        #endregion

    }
}
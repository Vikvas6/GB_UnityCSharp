﻿using UnityEngine;


namespace GeekbrainsUnityCSharp
{
    public class PlayerBall : Player
    {
        #region Contructor

        public PlayerBall(float speed) : base(speed)
        {
        }

        #endregion

        #region UnityMethods
        
        private void FixedUpdate()
        {
            Move();
        }

        #endregion


    }

}
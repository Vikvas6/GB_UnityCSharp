﻿
namespace GeekbrainsUnityCSharp
{
    public abstract class InteractiveObject
    {

        #region Methods

        protected abstract void Interact();
        
        public override string ToString()
        {
            return $"I am a {nameof(InteractiveObject)} class method";
        }


        #endregion

    }
}